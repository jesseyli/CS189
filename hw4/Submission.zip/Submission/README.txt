Jesse Li
SID: 23822462

All three coding problems can be found in hw4.py. Uncomment the desired portions of hw4.py and then run the script with python.  There are comments in the file that indicate where each new problem begins.