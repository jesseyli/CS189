Jesse Li
SID: 23822462

All the coding parts can be found in hw6.py. Uncomment the desired portions of hw6.py and then run the script with python.  There are comments in the file that indicate what each commented out section does.