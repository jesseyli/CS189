Jesse Li
SID: 23822462

To run my code (hw1.py), uncomment the desired portions of hw1.py and then run the script with python.  There are comments in the hw1.py file that describe what each commented out block does.  