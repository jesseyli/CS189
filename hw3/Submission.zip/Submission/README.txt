Jesse Li
SID: 23822462

I did problem 2 in MATLAB, to run it use MATLAB to open the file hw3_Q2.m. For the rest of the coding problems, uncomment the desired portions of hw3_Q3_Q5_Q6.py and then run the script with python.  There are comments in the hw3_Q3_Q5_Q6.py file that indicate where each new problem begins.